// Updated revealMore function with button text toggle
function revealMore(infoId, button) {
    const info = document.getElementById(infoId);
    
    // Toggle the visibility of the content
    if (info.style.display === 'none') {
        info.style.display = 'block';  // Show the content
        button.innerText = 'Read Less'; // Change button text to "Read Less"
    } else {
        info.style.display = 'none';   // Hide the content
        button.innerText = 'Read More'; // Change button text back to "Read More"
    }
}

// Form validation function
function validateForm() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    if (!name || !email || !message) {
        alert("All fields must be filled out.");
        return false;
    }
    return true;
}
